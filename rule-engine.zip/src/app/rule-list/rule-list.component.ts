import {EventEmitter, Input, Output} from '@angular/core';
import { Component, OnInit } from '@angular/core';
import {ConditionsBuilderService} from '../conditions-builder.service';

@Component({
  selector: 'app-rule-list',
  templateUrl: './rule-list.component.html',
  styleUrls: ['./rule-list.component.scss']
})
export class RuleListComponent implements OnInit {
  @Input() ruleList;
  @Output() singleRuleClick: EventEmitter<any>;

  constructor(private conditionsBuilder: ConditionsBuilderService) {
    this.singleRuleClick = new EventEmitter<any>();
  }

  ngOnInit() {
  }

  singleRuleClicked(idx) {
    const tree = this.conditionsBuilder.buildTreeFromBinaryTree(this.ruleList[idx].ruleConditionsEvaluation.conditionDisplay);
    this.singleRuleClick.emit(tree);
  }

}
