import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {DataServiceService} from '../data-service.service';

@Component({
  selector: 'app-rule-types-list',
  templateUrl: './rule-types-list.component.html',
  styleUrls: ['./rule-types-list.component.scss']
})
export class RuleTypesListComponent implements OnInit {
  ruleTypesList;
  @Output() ruleTypeSelected: EventEmitter<any>;

  constructor(dataService: DataServiceService) {
    this.ruleTypesList = dataService.getData().rulesProcessing;
    this.ruleTypeSelected = new EventEmitter<any>();
  }

  ngOnInit() {
  }

  ruleTypeClick(idx) {
    this.ruleTypeSelected.emit(this.ruleTypesList[idx].evaluatedRules);
  }

}
