import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-rule-conditions',
  templateUrl: './rule-conditions.component.html',
  styleUrls: ['./rule-conditions.component.scss']
})
export class RuleConditionsComponent implements OnInit {
@Input() ruleConditions;
@Input() logicalOperator;

  constructor() { }

  ngOnInit() {
    const aa = this.ruleConditions;
  }
}
